package aseCrypto;

import java.util.Scanner;

public class RSADecryptor {

    public static void main(String[] args) {
        try( final Scanner in = new Scanner(System.in) ){

            System.out.println("This program decrypts an RSA decrypted AseInteger slowly and once fast (using CRT)");

            //////////////////////////////////////////////////////
            // create a Carmichael number
            //////////////////////////////////////////////////////

            AseInteger p = new AseInteger("33617");
            AseInteger q = new AseInteger("68371");

            AseInteger n = calculateN(p, q);
            AseInteger phiOfN = calculatePhiOfN(p, q);

            AseInteger e = new AseInteger("59");
            AseInteger d = calculateD(e, phiOfN);

            AseInteger message = new AseInteger("1696233995"); // plain: 5000

            StopWatch watch = new StopWatch();

            System.out.println("Decrypt without CRT:");
            watch.start();
            System.out.println("Result:" + message.modPow(d, n));
            watch.stop();
            System.out.println("Decrypt without CRT took " + watch.getElapsedTime() + " ms");

            watch.reset();

            System.out.println("Decrypt using CRT:");
            watch.start();
            System.out.println("Result:" + message.modPowChinese(d, p, q));
            watch.stop();
            System.out.println("Decrypt using CRT took " + watch.getElapsedTime() + " ms");
        } finally {
            System.out.println("Program finished...");
        }
    }

    private static AseInteger calculateD(AseInteger e, AseInteger phiOfN) {
        AseInteger[] bezoutResult = e.getBezout(phiOfN);
        return bezoutResult[0];
    }

    private static AseInteger calculateN(AseInteger p, AseInteger q) {
        return p.multiply(q);
    }

    private static AseInteger calculatePhiOfN(AseInteger p, AseInteger q) {
        return p.subtract(AseInteger.ONE).multiply(q.subtract(AseInteger.ONE));
    }

}
