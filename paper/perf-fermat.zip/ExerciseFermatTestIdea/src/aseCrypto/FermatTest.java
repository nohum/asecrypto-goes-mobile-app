package aseCrypto;

import java.util.Random;

public class FermatTest {
	
	// after N tests, the user gets an informational message
	private static long informUserAfterNTests = 10000;
	
	/**
	 * This function creates a random AseInteger between 0 and modulus
	 * You can use this number as a witness in a Fermat test to check the primality of modulus
	 * 
	 * @param modulus is an upper bound for your test number
	 * @return a random AseInteger guaranteed to be >0 and <modulus
	 */
	private AseInteger createRandomTestNumber(AseInteger modulus){
		
		// get a random number
		AseInteger testNumber = new AseInteger(modulus.bitLength(), new Random());
		
		// assure that it is positive and smaller modulus
		testNumber = testNumber.mod(modulus);
		
		// assure that it is non zero
		if(testNumber.compareTo(AseInteger.ZERO)==0){
			testNumber = modulus.subtract(AseInteger.ONE);
		}
		return testNumber;
	}
	
	/**
	 * @param possiblePrime is the number to check for primality
	 * @param numOfTests is the number of times you want the test to run
	 * @param outputInfo decides whether info should be output to stdout for the user
	 * @return gives true if possiblePrime passed all tests, else false
	 */
	public boolean run(AseInteger possiblePrime, final long numOfTests, final boolean outputInfo){
		if(numOfTests <=0){
			return false;
		}
							
		StopWatch watch = new StopWatch();
		watch.start();
		
		// if possiblePrime is really prime, its phi is its value-1
		AseInteger exponent = possiblePrime.subtract(AseInteger.ONE);
		
		////////////////////////////////////////////////////////////////////
		// start a series of numOfTests FermatTests
		// that is exponentiate a test number 
		long counter = 1;
		for(counter=1; counter<=numOfTests; counter++){
			
			// create a random AseInteger as witness
			AseInteger randomNumber = createRandomTestNumber(possiblePrime);
			
			// check if a^(p-1) mod p <> 1

            if (randomNumber.modPow(exponent, possiblePrime).compareTo(AseInteger.ONE) != 0) {

			// if test failed
				watch.stop();
				if(outputInfo){
					System.out.println("Fermat test " + counter + " failed after " + watch.getElapsedTime() + " ms, " + possiblePrime + " is not a prime number!");
				}
				return false;
            }
			
			// inform the user of current state
			if(outputInfo && counter%informUserAfterNTests==0)
			{
				System.out.println(counter + " Fermat tests succeeded after " + watch.getElapsedTime() + " ms");
			}
		}
		
		// adjust counter to the number of tests actually done for correct output
        counter--;
		
		// all Fermat tests succeeded
		watch.stop();
		if(outputInfo){
			System.out.println("\nAfter " + watch.getElapsedTime() + " ms " + possiblePrime + " finally passed " + counter + " Fermat tests!" );
		}
		return true;

        /*
        2) Using the correctly finished application, determine for prime factors of bit size 5, 10, 15, 20, 25 and 30 how many Fermat Tests and
           Milliseconds it takes to determine a Carmichael number to be composite

           size 5:  count of tests =    500000, milliseconds = 70       -> Fermat test 157 failed after 70 ms, 56052361 is not a prime number!
           size 10: count of tests =    500000, milliseconds = 411      -> Fermat test 5193 failed after 411 ms, 464052305161 is not a prime number!
           size 15: count of tests =    500000, milliseconds = 584      -> Fermat test 8744 failed after 584 ms, 1004612946644089 is not a prime number!
           size 20: count of tests =   1000000, milliseconds = 1543     -> Fermat test 35385 failed after 1543 ms, 32101492985159401 is not a prime number!
           size 25: count of tests = 100000000, milliseconds = 46022    -> Fermat test 909990 failed after 46022 ms, 7060939430293796467249 is not a prime number!
           size 30: count of tests = 500000000, milliseconds = 13341090 -> Fermat test 201974199 failed after 13341090 ms, 79498893386897764115677849 is not a prime number!

        3) For how many bits of prime factor size does it take longer than 30 seconds (=30000 ms) to determine a Carmichael number to be composite

           Tests using 19 bit numbers (or with more bits) did take longer than 30 seconds. All tests have been made using 1.000.000 fermat tests.

        */
	}
}
