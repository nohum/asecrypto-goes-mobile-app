package carmichael;

import java.util.Scanner;

import aseCrypto.AseInteger;
import aseCrypto.CarMichaelCreator;
import aseCrypto.FermatTest;


public class Carmichael {
	private static int minBits = 4;
	private static long minFermatTests = 1;
	private static boolean outputInfo = true;
	
	public static void main(String[] args) {
		try( final Scanner in = new Scanner(System.in) ){
		
			System.out.println("This program uses a prime to test how long the fermat takes to execute");
			
			AseInteger prime = new AseInteger("11");
			
			// do a series of Fermat Test to demonstrate the danger of Carmichael numbers
			long tests = 0;
			do{
				System.out.println("\nPlease specify the number of Fermat tests you want to execute (minimum of " + minFermatTests + "):");
				tests = new Long(in.nextLine());
			}while(tests < minFermatTests);
			
			FermatTest fermatTest = new FermatTest();
			
			System.out.println("\nDoing Fermat tests unitl one witnesses the compositness of your Carmichael number or " + tests + " tests succeed.");
			boolean isPrime = fermatTest.run(prime, tests, outputInfo);
			if(isPrime){
				System.out.println("Your Fermat tests did not detect that your number is not prime!");
			} else {
				System.out.println("Your Fermat test detected the compositness of your number!");
			}
		} finally {
			System.out.println("Program finished...");
		}

	}
}
